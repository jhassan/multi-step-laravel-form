<footer class="footer section-bg-two">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="copyright text-center">
                    <p>Accbrains @ 2023 All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</footer>