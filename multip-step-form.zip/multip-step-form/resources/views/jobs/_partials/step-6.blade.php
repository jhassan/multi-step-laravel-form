<!-- multiStep Setting Starts -->
<div class="multiStep-wrapper-contents" style="width: 100%" id="form-step-6">
    <!-- Form -->
    <div action="javascript:void(0)"
        class="multiStep-form style-one simplePresentCart-two h-calc radius-0 white-bg radius-8">
        <div class="row">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="alert alert-success" id="show-message">
                        Please wait, email is sending ...
                    </div>
                    <div class="section-tittle-one text-center mb-25 d-none" id="success-box">
                        <!-- Check Mark icon -->
                        <div class="success-checkmarkStyle">
                            <div class="check-icon">
                                <span class="icon-line line-tip"></span>
                                <span class="icon-line line-long"></span>
                                <div class="icon-circle"></div>
                                <div class="icon-fix"></div>
                            </div>
                        </div>

                        <h3 class="title font-size-25 heading-color-two">
                            Congratulations </h3>
                        <p class="mb-25">Lorem ipsum dolor sit, amet consectetur
                            adipisicing elit. Voluptatibus
                            debitis error atque minus, voluptatem veniam
                            consequatur, saepe eos
                            natus repellat obcaecati aperiam sit qui laborum ad
                            suscipit sed aut
                            necessitatibus.Lorem ipsum dolor sit,amet consectetur
                            adipisicing elit. Voluptatibus debitis error atque
                            minus, voluptatem veniam consequatur, amet consectetur
                            adipisicing elit. Voluptatibus debitis error atque
                            minus, voluptatem veniam consequatur, saepe eos natus
                            repellat obcaecati aperiam sit qui laborum ad suscipit
                            sed aut necessitatibus.</p>

                        <p class="mb-10">Lorem ipsum dolor sit, amet consectetur
                            adipisicing elit. Voluptatibus debitis
                            error atque minus, voluptatem veniam consequatur, saepe
                            eos natus
                            repellat obcaecati aperiam sit qui laborum ad suscipit
                            sed aut
                            necessitatibus.Lorem ipsum dolor sit, amet consectetur
                            adipisicing elit.
                            Voluptatibus debitis error atque minus. Lorem ipsum
                            dolor sit, amet consectetur adipisicing elit.
                            Voluptatibus debitis
                            error atque minus</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Form -->
</div>
<!-- multiStep Setting Ends -->