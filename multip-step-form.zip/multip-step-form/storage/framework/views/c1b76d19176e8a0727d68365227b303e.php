<!DOCTYPE html>
<html class="loading" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-textdirection="ltr">
<!-- BEGIN: Head-->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    
    <meta name="description" content="">
    <meta name="keywords" content="">
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>
        <?php echo $__env->yieldContent('title', 'Dashboard'); ?> | <?php echo e(config('laravel-admin.app_name', config('app.name'))); ?>

    </title>
    
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600" rel="stylesheet">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/vendors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/extensions/toastr.css')); ?>">
    <?php echo $__env->yieldPushContent('vendor_css'); ?>
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/bootstrap-extended.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/colors.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/components.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/themes/dark-layout.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/themes/semi-dark-layout.css')); ?>">

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/core/menu/menu-types/vertical-menu.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/core/colors/palette-gradient.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/plugins/extensions/toastr.css')); ?>">

    <?php echo $__env->yieldPushContent('page_css'); ?>

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('app-assets/style.css')); ?>">

    <?php $__currentLoopData = config('laravel-admin.stylesheets', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stylesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <link rel="stylesheet" href="<?php echo e(asset($stylesheet)); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- END: Custom CSS-->
    
    <?php echo \Livewire\Livewire::styles(); ?>


    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<!-- END: Head-->
<!-- BODY -->
<body class="vertical-layout vertical-menu-modern <?php echo $__env->yieldContent('body_columns', 2); ?>-columns navbar-floating footer-static <?php echo $__env->yieldContent('body_extra_classes', 'menu-expanded'); ?>" data-open="click" data-menu="vertical-menu-modern" data-col="<?php echo $__env->yieldContent('body_columns', 2); ?>-columns">

    <?php echo $__env->yieldContent('main'); ?>


    <form method="POST" data-form-logout action="<?php echo e(route(config('laravel-admin.routes.user.logout', 'logout'))); ?>">
        <?php echo csrf_field(); ?>
    </form>

    <form method="POST" data-form-delete action="">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
    </form>

    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo e(asset('app-assets/vendors/js/vendors.min.js')); ?>"></script>
    <!-- BEGIN Vendor JS-->
    
    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('app-assets/vendors/js/extensions/toastr.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('vendor_js'); ?>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('app-assets/js/core/app-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/core/app.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/scripts/components.js')); ?>"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    
    <?php echo $__env->yieldPushContent('page_js'); ?>
    <!-- END: Page JS-->

    <?php $__currentLoopData = config('laravel-admin.scripts', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $script): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script src="<?php echo e(asset($script)); ?>" defer></script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(auth()->guard()->check()): ?>
        <script>
            jQuery(document).ready(function($) {
                $(document).on('click', '[data-logout]', function(event) {
                    event.preventDefault();
                    
                    $('form[data-form-logout]').trigger('submit')
                });
            });
        </script>
    <?php endif; ?>

    <script>
        jQuery(document).ready(function($) {
            function submit_delete_form(url){
                $('form[data-form-delete]').attr('action', url).trigger('submit').attr('action', '')
            }

            <?php if(session()->has('message')): ?>
                setTimeout(() => {
                    toastr['<?php echo e(session('status') ? 'success' : 'error'); ?>']('<?php echo e(session('message')); ?>');
                }, 0);
            <?php endif; ?>

            <?php if($errors->count()): ?>
                setTimeout(() => {
                    toastr.error('The given data was invalid')
                }, 0);
            <?php endif; ?>

            $(document).on('click', '[data-action_button]', function(event) {
                event.preventDefault();
                
                var action = $(this).data('action');

                if(action === 'remove' && confirm('Are you sure? you want to delete this item?')){
                    var action_url = $(this).data('action_url');
                    submit_delete_form(action_url);
                }
            });
        })
    </script>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldPushContent('lvjs'); ?>

    <?php echo $__env->yieldPushContent('js'); ?>
</body>
<!--/ BODY -->
</html>
<?php /**PATH /opt/lampp/htdocs/multi-step-laravel/vendor/jd-dotlogics/laravel-admin/src/resources/views/layouts/main.blade.php ENDPATH**/ ?>