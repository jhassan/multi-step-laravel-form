<!-- BEGIN: Main Menu-->
<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand" href="<?php echo e(config('laravel-admin.dashboard_url', '/')); ?>">
                    <div class="brand-logo"></div>
                    <h2 class="brand-text mb-0"><?php echo e(config('laravel-admin.sidebar.main_heading', 'Laravel Admin')); ?></h2>
                </a></li>
            <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="feather icon-x d-block d-xl-none font-medium-4 primary toggle-icon"></i><i class="toggle-icon feather icon-disc font-medium-4 d-none d-xl-block collapse-toggle-icon primary" data-ticon="icon-disc"></i></a></li>
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <?php echo $__env->make('laravel-admin::inc.sidebar-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>            
        </ul>
    </div>
</div>
<!-- END: Main Menu--><?php /**PATH /opt/lampp/htdocs/multi-step-laravel/vendor/jd-dotlogics/laravel-admin/src/resources/views/inc/sidebar.blade.php ENDPATH**/ ?>