<?php $__env->startSection('content'); ?>
    <section>
        <div class="row match-height">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e($entery); ?> detials</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <table class="table table-striped mb-0">
                                <tbody>
                                    <?php
                                        $dates = $item->getDates();   
                                    ?>

                                    <?php $__currentLoopData = $item->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            if(in_array($key, $dates)){
                                                $value = new \Carbon\Carbon($value);
                                            }                                            
                                        ?>
                                        <tr>
                                            <td><strong><?php echo e(title_case($key)); ?></strong></td>
                                            <td><?php echo e(toString($value)); ?></td>
                                        </tr>                                
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="2" class="text-right">
                                            <?php echo $actions ?? null; ?>

                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('laravel-admin::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/multi-step-laravel/vendor/jd-dotlogics/laravel-admin/src/resources/views/crud/details.blade.php ENDPATH**/ ?>