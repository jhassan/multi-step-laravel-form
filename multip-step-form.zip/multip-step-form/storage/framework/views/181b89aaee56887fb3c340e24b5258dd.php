<li class="dropdown dropdown-user nav-item">
    <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
        <div class="user-nav d-sm-flex d-none">
            <span class="user-name text-bold-600"><?php echo e(auth()->user()->name ?? ''); ?></span>
            <span class="user-status"><?php echo e(auth()->user()->role ?? ''); ?></span>
        </div>
        <span>
            <img class="round" src="<?php echo e(auth()->user()->avatar_url ?? '/assets/img/logo/logo.png'); ?>" alt="avatar" height="40" width="40">
        </span>
    </a>
    <div class="dropdown-menu dropdown-menu-right">
        <?php if(app()->router->has('laravel-admin.profile.edit')): ?>
            <a class="dropdown-item" href="<?php echo e(route(config('laravel-admin.routes.profile.edit', 'laravel-admin.profile.edit'))); ?>">
                <i class="feather icon-user"></i> Edit Profile
            </a>                           
            <div class="dropdown-divider"></div>
        <?php endif; ?>

        <a class="dropdown-item" href="" data-logout>
            <i class="feather icon-power"></i> Logout
        </a>
    </div>
</li><?php /**PATH /opt/lampp/htdocs/multi-step-laravel/resources/views/vendor/laravel-admin/inc/user-menu.blade.php ENDPATH**/ ?>