<?php if(!empty($page_title)): ?>
    <?php
        $title = $page_title;

        if(!empty($page)){
           $title = "{$page->title} - {$title}";
        }
    ?>
    <?php $__env->startSection('title', $title); ?>
<?php endif; ?>

<?php $__env->startPush('page_css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/plugins/forms/validation/form-validation.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .dropzone{
            min-height: 100px;
        }

        .input-image-preview{
            height: 100px;
            /*text-align: center;*/
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <?php echo $__env->make('laravel-admin::inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('laravel-admin::inc.sidebar', ['menu_active' => $menu_active ?? 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">                
                <?php if(!empty($page_title)): ?>
                    <div class="content-header-left col-md-9 col-12 mb-2">
                        <div class="row breadcrumbs-top">
                            <div class="col-12">
                                <h2 class="content-header-title float-left mb-0"><?php echo e($page_title); ?></h2>
                               
                                <?php if(!empty($breadcrumbs)): ?>
                                    <div class="breadcrumb-wrapper col-12">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="/">Home</a>
                                            </li>
                                            <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="breadcrumb-item <?php echo e($loop->last ? 'active' : ''); ?>">
                                                    <?php if($loop->last || is_null($url)): ?>
                                                        <?php echo e($name); ?>

                                                    <?php else: ?>
                                                        <a href="<?php echo e($url); ?>"><?php echo e($name); ?></a>
                                                    <?php endif; ?>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="content-body">

                <?php echo $__env->yieldContent('content'); ?>

            </div>
        </div>
    </div>

    <?php echo $__env->make('laravel-admin::inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.tiny.cloud/1/plvfgap34uuvzkaly2pp6oeweszgvb15ra0q9ff7jqvwrmdv/tinymce/4/tinymce.min.js" referrerpolicy="origin"></script>

    <script type="text/javascript">
        jQuery(document).ready(function($) {
            tinymce.init({
                selector: '.rich-editor',
                branding: false,
                plugins: 'code link',
                menubar: false,
                toolbar: 'undo redo | styleselect link | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | code',
            });

            tinymce.init({
                selector: '.rich-editor-advance',
                branding: false,
                plugins: 'code link image',
                menubar: false,
                toolbar: 'undo redo | styleselect | link image | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | code',
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('laravel-admin::layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/multi-step-laravel/vendor/jd-dotlogics/laravel-admin/src/resources/views/layouts/app.blade.php ENDPATH**/ ?>