<div class="sidenav-overlay"></div>
<div class="drag-target"></div>

<?php if(config('laravel-admin.footer.show_copyright', false)): ?>
	<!-- BEGIN: Footer-->
	<footer class="footer footer-static footer-light">
	    <p class="clearfix blue-grey lighten-2 mb-0">
	    	<span class="float-md-left d-block d-md-inline-block mt-25">
	    	<?php echo config('laravel-admin.footer.copyright_text', ''); ?>

	    </p>
	</footer>
	<!-- END: Footer-->
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/multi-step-laravel/vendor/jd-dotlogics/laravel-admin/src/resources/views/inc/footer.blade.php ENDPATH**/ ?>