<li class="navigation-header"><span>Job</span></li>

<li class="nav-item <?php echo e($menu_active == 'jobs' ? 'active' : ''); ?>">
    <a href="<?php echo e(route('laravel-admin.jobs.index')); ?>">
        <i class="feather icon-archive"></i>
        <span class="menu-title">Jobs</span>
    </a>
</li>

<?php /**PATH /opt/lampp/htdocs/multi-step-laravel/resources/views/vendor/laravel-admin/inc/sidebar-menu.blade.php ENDPATH**/ ?>