<?php $__env->startSection('content'); ?>
    <!-- Zero configuration table -->
    <section id="basic-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title w-100">
                            <div class="row align-items-center">
                                <div class="col">
                                    <?php if(!empty($filter_fields)): ?>
                                        <form name="table-filters" class="row">
                                            <?php $__currentLoopData = $filter_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-<?php echo e($field['cols'] ?? 'md-4'); ?> <?php echo e(($field['append_to_create_link'] ?? false) ? 'append_to_create_link' : ''); ?>">
                                                    <?php
                                                        $field['default']  = request($field['name'], $field['default'] ?? null);
                                                        $field['cols'] = '12 p-0';
                                                    ?>
                                                    
                                                    <?php echo $__env->make('laravel-admin::fields.field', $field, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </form> 
                                    <?php endif; ?>
                                </div>

                                <?php if($links->create !== null): ?>
                                    <div class="col-md-2">
                                        <div class="text-right link-create">
                                            <?php if(!empty($links->create->html)): ?>
                                                <?php echo $links->create->html; ?>

                                            <?php else: ?>
                                                <a href="<?php echo e($links->create->link); ?>" class="btn btn-sm btn-success"><?php echo e($links->create->text); ?></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body card-dashboard">
                            
                            <div class="table-responsive">
                                <table class="table jd-datatable">
                                    <thead>
                                        <tr>
                                            <?php $__currentLoopData = $table_columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $column['title'] = $column['title'] ?? $column['name'] ?>
                                                <th class="<?php echo e(($column['hidden'] ?? false) ? 'no-show' : ''); ?> <?php echo e(!($column['searchable'] ?? true) ? 'no-search' : ''); ?> <?php echo e(($column['sortable'] ?? $column['name'] !== 'actions' ) ? '' : 'no-sort'); ?>"><?php echo e(title_case($column['title'])); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laravel-admin::inc.datatables-config', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('laravel-admin::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/multi-step-laravel/vendor/jd-dotlogics/laravel-admin/src/resources/views/crud/list.blade.php ENDPATH**/ ?>