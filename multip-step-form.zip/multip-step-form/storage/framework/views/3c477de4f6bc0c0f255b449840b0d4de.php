<header>
    <div class="header-area">
        <div class="main-header">
            <div class="header-bottom">
                <div class="container">
                    <div class="row align-items-center">
                        <!-- Logo -->
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo">
                                <a href="/" style="color: #0dcaf0; border: 2px solid #ba895d; padding: 10px 40px; border-radius: 8px; font-size: 20px;">AccBrains</a>
                            </div>
                        </div>
                        <div class="col-xl-10 col-lg-10">
                            <div class="menu-wrapper  d-flex align-items-center justify-content-end">
                                <!-- Main-menu -->
                                <div class="main-menu d-none d-lg-block" style="display:none;">
                                    <nav>
                                        <ul id="navigation">
                                            <li><a href="index.html#contact">Reach to us</a></li>


                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                        <!-- Mobile Menu -->
                        <div class="col-12">
                            <div class="mobile_menu d-block d-lg-none"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH /opt/lampp/htdocs/multi-step-laravel/resources/views/includes/header.blade.php ENDPATH**/ ?>