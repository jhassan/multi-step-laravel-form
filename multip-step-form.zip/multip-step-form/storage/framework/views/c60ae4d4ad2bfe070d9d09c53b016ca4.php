<div class="multiStep-wrapper-left h-calc radius-8">
  <!-- <div class="single-multiStep"> -->
  <ul class="step-list-wrapper list-style-none">
      <li class="single-step-list-step current-items">
          <span class="single-multiStep-request-list-item-number"> 1 </span>
          <div class="single-step-list-contents">
              <h5 class="title"> Expertise </h5>
          </div>
      </li>
      <li class="single-step-list-step">
          <span class="single-multiStep-request-list-item-number"> 2 </span>
          <div class="single-step-list-contents">
              <h5 class="title"> Job Prefrences </h5>
          </div>
      </li>
      <li class="single-step-list-step">
          <span class="single-multiStep-request-list-item-number"> 3 </span>
          <div class="single-step-list-contents">
              <h5 class="title"> Relocation </h5>
          </div>
      </li>
      <li class="single-step-list-step">
          <span class="single-multiStep-request-list-item-number"> 4 </span>
          <div class="single-step-list-contents">
              <h5 class="title"> Insights </h5>
          </div>
      </li>
      <li class="single-step-list-step">
          <span class="single-multiStep-request-list-item-number"> 4 </span>
          <div class="single-step-list-contents">
              <h5 class="title"> Account </h5>
          </div>
      </li>
      <li class="single-step-list-step">
          <span class="single-multiStep-request-list-item-number"> 6 </span>
          <div class="single-step-list-contents">
              <h5 class="title"> Submission </h5>
          </div>
      </li>
  </ul>
  <!-- </div> -->
</div><?php /**PATH /opt/lampp/htdocs/multi-step-laravel/resources/views/jobs/left-side-bar.blade.php ENDPATH**/ ?>