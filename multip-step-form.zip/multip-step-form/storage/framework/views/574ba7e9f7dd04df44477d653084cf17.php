<?php $__env->startSection('content'); ?>
    <section>
        <div class="row match-height">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e($editing_form ? 'Modify' : 'Add new'); ?> <?php echo e($entery); ?></h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form form-vertical <?php echo e($errors->count() ? 'error' : ''); ?>" enctype="multipart/form-data" method="post" action="<?php echo e($editing_form ? route("{$route_base}.update", $item->id) : route("{$route_base}.store")); ?>" novalidate>
                                <?php echo csrf_field(); ?>

                                <?php if($editing_form): ?>
                                    <?php echo method_field('PUT'); ?>
                                <?php endif; ?>

                                <div class="form-body">
                                    <div class="row">
                                        <?php $__currentLoopData = $form_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $__env->make('laravel-admin::fields.field', $field, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary mr-1 mb-1 waves-effect waves-light">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('laravel-admin::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/multi-step-laravel/vendor/jd-dotlogics/laravel-admin/src/resources/views/crud/form.blade.php ENDPATH**/ ?>